from прати import АТАКИ, прати

import logging
log = logging.getLogger('прати')
log.setLevel(logging.INFO)

успехи = 0
for атака in АТАКИ:
    try:
        прати('алек', 'цвети', 10, атака)
        успехи += 1
        print("Успешна атака", атака)
        откажи()
    except:
        pass

print("Успехи", успехи, 'oт', len(АТАКИ))
