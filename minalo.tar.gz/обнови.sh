cd ..
rm -rf минало/*
wget https://zhiva.be/minalo.tar.gz
tar -xvf ../minalo.tar.gz -C минало
cd минало
