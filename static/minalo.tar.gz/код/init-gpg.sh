export GNUPGHOME=$(pwd)/тайник
