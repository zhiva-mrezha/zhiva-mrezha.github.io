virtualenv venv
source venv/bin/activate
pip install -r requirements.txt

#TODO направи тайник
git config pager.branch false
